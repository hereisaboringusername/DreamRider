package com.mygdx.game;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.graphics.g2d.Animation;
import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.graphics.g2d.TextureAtlas;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.utils.Array;

public class ArcherSprite1 extends Sprite {
    private TextureAtlas textureAtlas;
    private Animation walkRightAnimation, walkLeftAnimation;
    private boolean alive;

    // Save flying dragon sprite frames in an Array for later:
    private Array<TextureAtlas.AtlasRegion> walkLeftLoop, walkRightLoop;

    // Store dead animation
    private TextureRegion deathFromLeft, deathFromRight;
    private TextureRegion jumpLeft, jumpRight;

    public ArcherSprite1() {
        textureAtlas = new TextureAtlas(Gdx.files.internal("ArcherSprites.atlas"));

        walkRightLoop = textureAtlas.findRegions("WalkRightLoop");
        walkRightAnimation = new Animation(1/5f, walkRightLoop);

        walkLeftLoop = textureAtlas.findRegions("WalkLeftLoop");
        walkLeftAnimation = new Animation(1/5f, walkLeftLoop);


        // Store "dead" dragon frame from textureAtlas:
        deathFromLeft = textureAtlas.findRegion("DeathFromLeft");
        deathFromRight = textureAtlas.findRegion("DeathFromRight");
        jumpLeft = textureAtlas.findRegion("JumpLeft");
        jumpRight = textureAtlas.findRegion("JumpRight");

        // Set the bounds of the texture region
        setBounds(0, 0, deathFromLeft.getRegionWidth(), deathFromLeft.getRegionHeight());
        setBounds(0,0, deathFromRight.getRegionWidth(), deathFromRight.getRegionHeight());
        setBounds(0,0, jumpLeft.getRegionWidth(),jumpLeft.getRegionHeight());
        setBounds(0,0, jumpRight.getRegionWidth(), jumpRight.getRegionHeight());


        // Set where the regions will start
        setRegion(walkRightLoop.get(0));
        setRegion(walkLeftLoop.get(0));
        alive = true;

    }

    public void setAlive(){
        alive = true;
    }

    public boolean isAlive() {
        return alive;
    }

    public void kill() {
        alive = false;
        setRegion(deathFromLeft);
    }

    public void turnAroundLeft() {
        setRegion(walkRightLoop.get(0));
    }

    public void turnAroundRight() {
        setRegion(walkLeftLoop.get(0));
    }

    public void update(float elapsedTime) {
        // Set the next frame for the DragonSprite:

        if (alive) {
            // Walking left
            if(Gdx.input.isKeyJustPressed(Input.Keys.A)) {
                setRegion((TextureRegion) walkLeftAnimation.getKeyFrame(elapsedTime, true));
            }

            // Walking right
            else if(Gdx.input.isKeyJustPressed(Input.Keys.D)) {
                setRegion((TextureRegion) walkRightAnimation.getKeyFrame(elapsedTime, true));
            }

            // Jumping
            else if(Gdx.input.isKeyJustPressed(Input.Keys.W)) {
               setRegion(jumpRight);
            }

        }
        // If the player is dead:
        else {
            setRegion(deathFromLeft);
        }
    }
}
