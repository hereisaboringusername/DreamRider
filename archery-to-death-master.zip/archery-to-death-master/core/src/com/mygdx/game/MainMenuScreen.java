package com.mygdx.game;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.scenes.scene2d.InputEvent;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.Touchable;
import com.badlogic.gdx.scenes.scene2d.ui.Label;
import com.badlogic.gdx.scenes.scene2d.utils.ClickListener;
import com.mygdx.game.MyGdxGame;

public class MainMenuScreen extends MyGdxGame implements Screen {
    Texture background;
    Sprite backgroundSprite;
    final MyGdxGame game;
    GameScreen gameScreen;
    InstructionScreen instructionScreen;
    private Stage stage;
    private Label startLabel;
    private Label instructionLabel;
    private Label quitLabel;
    private BitmapFont font;


    public MainMenuScreen(final MyGdxGame gam) {
        background = new Texture("splash.png");
        backgroundSprite = new Sprite(background);
        backgroundSprite.setBounds(0f, 0f, 1200f, 900f);
        game = gam;

        // Pass this MainMenuScreen to a new GameScreen along with the game object,
        // so that the GameScreen can switch back to this MainMenuScreen when paused.
        gameScreen = new GameScreen(game, this);
        instructionScreen = new InstructionScreen(game);
        camera = new OrthographicCamera();
        camera.setToOrtho(false, 800, 480);

        // PROCESS MOUSE CLICKS IN STAGE
        stage = new Stage();
        Gdx.input.setInputProcessor(stage);

    }
    public void render(float delta) {
        Gdx.gl.glClearColor(0, 0, 0.2f, 1);
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);

        camera.update();
        game.batch.setProjectionMatrix(camera.combined);

        // Note that we use the game object's SpriteBatch to draw.
        game.batch.begin();

        // Here is where you could draw a background image.
        backgroundSprite.draw(game.batch);
        game.batch.end();
        stage.draw();

    }
    public void show() {
        Gdx.input.setInputProcessor(stage);

        // Define startLabel data and click listener
        font = new BitmapFont();
        startLabel = new Label("Start/Resume Game", new Label.LabelStyle(font, Color.ORANGE));
        startLabel.setPosition(400,280);
        startLabel.setTouchable(Touchable.enabled);
        startLabel.setBounds(400,280,startLabel.getWidth(),startLabel.getHeight());
        startLabel.addListener(new ClickListener() {
            @Override
            public void clicked(InputEvent event, float x, float y) {
                // Switch to new GameScreen or return to already existing GameScreen
                gameScreen.setGameState(GameStatus.RUN);
                game.setScreen(gameScreen);
                dispose();
            }
        });
        // Define quitLabel data and click listener
        quitLabel = new Label("Quit", new Label.LabelStyle(font, Color.ORANGE));
        quitLabel.setPosition(400, 180);
        quitLabel.setTouchable(Touchable.enabled);
        quitLabel.setBounds(400,180,quitLabel.getWidth(),quitLabel.getHeight());
        quitLabel.addListener(new ClickListener() {
            @Override
            public void clicked(InputEvent event, float x, float y) {
                Gdx.app.exit();
            }
        });
        instructionLabel = new Label("Instructions", new Label.LabelStyle(font, Color.ORANGE));
        instructionLabel.setPosition(400, 230);
        instructionLabel.setTouchable(Touchable.enabled);
        instructionLabel.setBounds(400,230,instructionLabel.getWidth(),instructionLabel.getHeight());
        instructionLabel.addListener(new ClickListener() {
            @Override
            public void clicked(InputEvent event, float x, float y) {
                game.setScreen(instructionScreen);
                dispose();
            }
        });
        // Add labels to screen
        stage.addActor(startLabel);
        stage.addActor(instructionLabel);
        stage.addActor(quitLabel);
    }
    public void resize(int width, int height) {
    }
    public void hide() {
    }

    public void pause() {
    }

    public void resume() {
    }

    public void dispose() {
        startLabel.setTouchable(Touchable.disabled);
        quitLabel.setTouchable(Touchable.disabled);
    }
}
