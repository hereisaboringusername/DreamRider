package com.mygdx.game;

public enum GameStatus {
    // Implement pause/resume
    RUN, PAUSE, END
}
