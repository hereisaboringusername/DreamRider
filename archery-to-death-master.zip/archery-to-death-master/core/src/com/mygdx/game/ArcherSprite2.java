package com.mygdx.game;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.graphics.g2d.Animation;
import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.graphics.g2d.TextureAtlas;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.utils.Array;

public class ArcherSprite2 extends Sprite {
    private TextureAtlas textureAtlas;
    private Animation walkRightAnimation2, walkLeftAnimation2;
    private boolean alive;

    // Create the array holding the frames for walking
    private Array<TextureAtlas.AtlasRegion> walkLeft2Loop, walkRight2Loop;

    // Store dead animation
    private TextureRegion deathFrLeft, deathFrRight;
    private TextureRegion jumpLeft2, jumpRight2;

    public ArcherSprite2() {
        textureAtlas = new TextureAtlas(Gdx.files.internal("ArcherSprites.atlas"));

        walkRight2Loop = textureAtlas.findRegions("WalkRight2loop");
        walkRightAnimation2 = new Animation(1/5f, walkRight2Loop);

        walkLeft2Loop = textureAtlas.findRegions("WalkLeft2loop");
        walkLeftAnimation2 = new Animation(1/5f, walkLeft2Loop);


        // Store "dead" dragon frame from textureAtlas:
        deathFrLeft = textureAtlas.findRegion("DeathFrLeft2");
        deathFrRight = textureAtlas.findRegion("DeathFrRight2");
        jumpLeft2 = textureAtlas.findRegion("JumpLeft2");
        jumpRight2 = textureAtlas.findRegion("JumpRight2");

        // Set the bounds of the texture region
        setBounds(0, 0, deathFrLeft.getRegionWidth(), deathFrLeft.getRegionHeight());
        setBounds(0,0, deathFrRight.getRegionWidth(), deathFrRight.getRegionHeight());
        setBounds(0,0, jumpLeft2.getRegionWidth(),jumpLeft2.getRegionHeight());
        setBounds(0,0, jumpRight2.getRegionWidth(), jumpRight2.getRegionHeight());


        // Set where the regions will start
        setRegion(walkRight2Loop.get(0));
        setRegion(walkLeft2Loop.get(0));
        alive = true;
    }

    public void setAlive(){
        alive = true;
    }

    public boolean isAlive() {
        return alive;
    }

    public void kill() {
        alive = false;
        setRegion(deathFrLeft);
    }

    public void update(float elapsedTime) {
        // Set the next frame for the DragonSprite:
        if (alive) {
            // Walking left
            if(Gdx.input.isKeyJustPressed(Input.Keys.LEFT)) {
                setRegion((TextureRegion) walkLeftAnimation2.getKeyFrame(elapsedTime, true));
            }

            // Walking right
            else if(Gdx.input.isKeyJustPressed(Input.Keys.RIGHT)) {
                setRegion((TextureRegion) walkRightAnimation2.getKeyFrame(elapsedTime, true));
            }

            // Jumping
            else if(Gdx.input.isKeyJustPressed(Input.Keys.UP)) {
                setRegion(jumpRight2);
            }

        }
        // If the player is dead:
        else {
            setRegion(deathFrLeft);
        }
    }
}
