package com.mygdx.game;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.Input.Keys;
import com.badlogic.gdx.InputProcessor;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.audio.Sound;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.math.Matrix4;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.physics.box2d.Body;
import com.badlogic.gdx.physics.box2d.BodyDef;
import com.badlogic.gdx.physics.box2d.Box2DDebugRenderer;
import com.badlogic.gdx.physics.box2d.Contact;
import com.badlogic.gdx.physics.box2d.ContactImpulse;
import com.badlogic.gdx.physics.box2d.ContactListener;
import com.badlogic.gdx.physics.box2d.EdgeShape;
import com.badlogic.gdx.physics.box2d.FixtureDef;
import com.badlogic.gdx.physics.box2d.Manifold;
import com.badlogic.gdx.physics.box2d.PolygonShape;
import com.badlogic.gdx.physics.box2d.World;
import com.badlogic.gdx.utils.Timer;

public class GameScreen extends MyGdxGame implements Screen, InputProcessor {
    private World world;
    //BACKGROUND
    private static Texture backgroundTexture;
    private static Sprite backgroundSprite;

    //IMAGES
    private Texture imgPlatform;

    //PLAYERS
    private ArcherSprite1 archer1;
    private ArcherSprite2 archer2;
    private Body body1, body2;
    private int archer1HP = 3, archer2HP = 3;
    private boolean isHit = false, hit = false; //false = archer2 loses hp, true = archer1 loses hp

    // ANIMATION FRAME TRACKING
    private float elapsedTime, elapsedTime2;

    //Font
    private BitmapFont font;
    private int fontX1 = 10000, fontY1 = 10000, fontX2 = 10000, fontY2 = 10000, endfontX1 = 1000, endfontX2 = 1000, endfontY1 = 1000, endfontY2 = 1000;

    //WORLD BORDERS
    private Body bodyEdgeScreen, bodyEdgeLeft, bodyEdgeRight, bodyEdgeScreenTop;

    //PLATFORMS INITIALIZATION
    private Sprite spriteMid, spriteLeft, spriteUpperLeft, spriteRight, spriteUpperRight;
    private Body bodyMidPlatform, bodyLeftPlatform, bodyRightPlatform, bodyUpperLeftPlatform, bodyUpperRightPlatform;

    //Shooting
    private Texture arrow1, arrow2;
    private Body arrow1Body, arrow2Body;
    private  Sprite arrow1Sprite, arrow2Sprite;
    private float arrowVelocity= 4f;
    private boolean canShoot1 = true, alreadyShot1 = false, canShoot2 = true, alreadyShot2 = false;
    private boolean shootRight1 = true, shootRight2 = false; //The archer is shooting to the right
    private boolean canInput1 = true, canInput2 = true;
    private boolean arrow1Direction = true;    //true = right direction
    private boolean arrow2Direction = true;    //true = left direction
    //MOVEMENT
    private int isWKeyPressed, isUpKeyPressed;
    private boolean isAir1 = false, isLeft1 = false, isRight1 = false, isAir2 = false, isLeft2 = false, isRight2 = false;
    private final float HORIZONTAL_VELOCITY = 15f; // Velocity when pressing or holding Left/Right or A/D
    private final float MAX_HORIZONTAL_VELOCITY = 3.5f; // Max horizontal speed

    private Box2DDebugRenderer debugRenderer;
    private Matrix4 debugMatrix;
    private OrthographicCamera camera;

    // WORLD SCALE
    final private float PIXELS_TO_METERS = 100f;

    // Apply filters for collision handling
    final private short PHYSICS_ENTITY = 0x1;    // 0001
    final private short WORLD_ENTITY = 0x1 << 1; // 0010 or 0x2 in hexadecimal

    private Boolean lose1 = false, lose2 = false;

    final MyGdxGame game;

    // Since we want to be able to switch to the MainMenuScreen from the GameScreen
    private MainMenuScreen mainmenu;

    // To enable pausing/resuming
    public GameStatus status = GameStatus.RUN;

    // SOUNDS
    private Sound shotSound;

    // The GameScreen constructor needs references to the Game object and
    // the MainMenuScreen
    public GameScreen(final MyGdxGame gam, MainMenuScreen pmainmenu) {
        this.game = gam;
        this.mainmenu = pmainmenu;
        batch = new SpriteBatch();

        //Sounds initiation
        shotSound = Gdx.audio.newSound(Gdx.files.internal("ArrowSwoosh.ogg"));

        // Size of the world
        float w = Gdx.graphics.getWidth()/PIXELS_TO_METERS;
        float h = Gdx.graphics.getHeight()/PIXELS_TO_METERS;

        // Create the image
        imgPlatform = new Texture("Mid.png");
        arrow1 = new Texture("arrow2.png");
        arrow2 = new Texture("arrow2.png");

        //Creates font for onscreen text
        font = new BitmapFont();
        font.setColor(Color.BLACK);
        font.getData().setScale(1, 1);

        // Create a background
        backgroundTexture = new Texture("splash.png");
        backgroundSprite =new Sprite(backgroundTexture);
        backgroundSprite.setPosition(-500,-225);

        //Mid platform sprite
        spriteMid = new Sprite(imgPlatform);
        spriteMid.setPosition(0 - spriteMid.getWidth()/2 , -25);
        //spriteMid.setColor(19,1,1,100);

        //Left platform sprite
        spriteLeft = new Sprite(imgPlatform);
        spriteLeft.setPosition(-425 , -150);

        //Upper Left platfrom sprite
        spriteUpperLeft = new Sprite(imgPlatform);
        spriteUpperLeft.setPosition(-425 , 100);

        //Right platform sprite
        spriteRight = new Sprite(imgPlatform);
        spriteRight.setPosition(225 , -150);

        //Upper Right platform sprite
        spriteUpperRight = new Sprite(imgPlatform);
        spriteUpperRight.setPosition(225 , 100);

        //Create the world
        world = new World(new Vector2(0, -1f),true);

        // BELOW EDGE
        BodyDef bodyDef3 = new BodyDef();
        bodyDef3.type = BodyDef.BodyType.StaticBody;
        bodyDef3.position.set(0,0);
        FixtureDef fixtureDef3 = new FixtureDef();
        fixtureDef3.filter.categoryBits = WORLD_ENTITY;
        fixtureDef3.filter.maskBits = PHYSICS_ENTITY; // allow collision with boxes
        EdgeShape edgeShape = new EdgeShape();
        edgeShape.set(-w/2,-h/2,w/2,-h/2);
        fixtureDef3.shape = edgeShape;
        bodyEdgeScreen = world.createBody(bodyDef3);
        bodyEdgeScreen.createFixture(fixtureDef3);
        edgeShape.dispose();

        // TOP EDGE
        BodyDef bodyDefTop = new BodyDef();
        bodyDefTop.type = BodyDef.BodyType.StaticBody;
        bodyDefTop.position.set(0,0);
        FixtureDef fixtureDefTop = new FixtureDef();
        fixtureDefTop.filter.categoryBits = WORLD_ENTITY;
        fixtureDefTop.filter.maskBits = PHYSICS_ENTITY; // allow collision with boxes
        EdgeShape edgeShapeTop = new EdgeShape();
        edgeShapeTop.set(-w/2,h/2,w/2,h/2);
        fixtureDefTop.shape = edgeShape;
        bodyEdgeScreenTop = world.createBody(bodyDefTop);
        bodyEdgeScreenTop.createFixture(fixtureDefTop);
        edgeShapeTop.dispose();
        ////////////////////////////////////////////////////////
        //RIGHT SIDE
        BodyDef bodyDef4 = new BodyDef();
        bodyDef4.type = BodyDef.BodyType.StaticBody;
        bodyDef4.position.set(0,0);
        FixtureDef fixtureDef4 = new FixtureDef();
        fixtureDef4.filter.categoryBits = WORLD_ENTITY;
        fixtureDef4.filter.maskBits = PHYSICS_ENTITY; // allow collision with boxes
        EdgeShape edgeShape1 = new EdgeShape();
        edgeShape1.set(w/2,h/2,w/2,-h/2);
        fixtureDef4.shape = edgeShape1;
        bodyEdgeRight = world.createBody(bodyDef4);
        bodyEdgeRight.createFixture(fixtureDef4);
        edgeShape1.dispose();
        ////////////////////////////////////////////////////////
        //LEFT SIDE
        BodyDef bodyDef5 = new BodyDef();
        bodyDef5.type = BodyDef.BodyType.StaticBody;
        bodyDef5.position.set(0,0);
        FixtureDef fixtureDef5 = new FixtureDef();
        fixtureDef5.filter.categoryBits = WORLD_ENTITY;
        fixtureDef5.filter.maskBits = PHYSICS_ENTITY; // allow collision with boxes
        EdgeShape edgeShape2 = new EdgeShape();
        edgeShape2.set(-w/2,-h/2,-w/2,h/2);//ASK HERE !!!
        fixtureDef5.shape = edgeShape2;
        bodyEdgeLeft = world.createBody(bodyDef5);
        bodyEdgeLeft.createFixture(fixtureDef5);
        edgeShape2.dispose();

        //MIDDLE FLOATING PLATFORM
        //Create a BodyDef
        BodyDef midPlatformB = new BodyDef();
        midPlatformB.type = BodyDef.BodyType.StaticBody;
        midPlatformB.position.set((spriteMid.getX()+spriteMid.getWidth()/2)/PIXELS_TO_METERS, (spriteMid.getY() + spriteMid.getHeight()/2)/PIXELS_TO_METERS);
        //Create a Fixture
        FixtureDef midPlatformF = new FixtureDef();
        midPlatformF.density =1;
        midPlatformF.restitution = 0f;
        //Shape
        PolygonShape midPlatformR = new PolygonShape();
        midPlatformR.setAsBox(spriteMid.getWidth()/2/PIXELS_TO_METERS,spriteMid.getHeight()/2/PIXELS_TO_METERS);
        midPlatformF.shape = midPlatformR;
        midPlatformF.filter.categoryBits = WORLD_ENTITY;
        midPlatformF.filter.maskBits = PHYSICS_ENTITY; // allow collision with boxes
        //Create a Body
        bodyMidPlatform = world.createBody(midPlatformB);
        bodyMidPlatform.createFixture(midPlatformF);
        midPlatformR.dispose();

        //LEFT FLOATING PLATFORM
        //Create a BodyDef
        BodyDef leftPlatformB = new BodyDef();
        leftPlatformB.type = BodyDef.BodyType.StaticBody;
        leftPlatformB.position.set((spriteLeft.getX()+spriteLeft.getWidth()/2)/PIXELS_TO_METERS, (spriteLeft.getY() + spriteLeft.getHeight()/2)/PIXELS_TO_METERS);

        //Create a Fixture
        FixtureDef leftPlatformF = new FixtureDef();
        leftPlatformF.density =1;
        leftPlatformF.restitution = 0f;
        //Shape
        PolygonShape leftPlatformR = new PolygonShape();
        leftPlatformR.setAsBox(spriteLeft.getWidth()/2/PIXELS_TO_METERS,spriteLeft.getHeight()/2/PIXELS_TO_METERS);
        leftPlatformF.shape = leftPlatformR;
        leftPlatformF.filter.categoryBits = WORLD_ENTITY;
        leftPlatformF.filter.maskBits = PHYSICS_ENTITY; // allow collision with boxes
        //Create a Body
        bodyLeftPlatform = world.createBody(leftPlatformB);
        bodyLeftPlatform.createFixture(leftPlatformF);
        leftPlatformR.dispose();

        //UPPER LEFT FLOATING PLATFORM
        //Create a BodyDef
        BodyDef leftUpperPlatformB = new BodyDef();
        leftUpperPlatformB.type = BodyDef.BodyType.StaticBody;
        leftUpperPlatformB.position.set((spriteUpperLeft.getX()+spriteUpperLeft.getWidth()/2)/PIXELS_TO_METERS, (spriteUpperLeft.getY() + spriteUpperLeft.getHeight()/2)/PIXELS_TO_METERS);
        //Create a Fixture
        FixtureDef leftUpperPlatformF = new FixtureDef();
        leftUpperPlatformF.density =1;
        leftUpperPlatformF.restitution = 0f;
        //Shape
        PolygonShape leftUpperPlatformR = new PolygonShape();
        leftUpperPlatformR.setAsBox(spriteUpperLeft.getWidth()/2/PIXELS_TO_METERS,spriteUpperLeft.getHeight()/2/PIXELS_TO_METERS);
        leftUpperPlatformF.shape = leftUpperPlatformR;
        leftUpperPlatformF.filter.categoryBits = WORLD_ENTITY;
        leftUpperPlatformF.filter.maskBits = PHYSICS_ENTITY; // allow collision with boxes
        //Create a Body
        bodyUpperLeftPlatform = world.createBody(leftUpperPlatformB);
        bodyUpperLeftPlatform.createFixture(leftUpperPlatformF);
        leftUpperPlatformR.dispose();

        //RIGHT FLOATING PLATFORM
        //Create a BodyDef
        BodyDef rightPlatformB = new BodyDef();
        rightPlatformB.type = BodyDef.BodyType.StaticBody;
        rightPlatformB.position.set((spriteRight.getX()+spriteRight.getWidth()/2)/PIXELS_TO_METERS, (spriteRight.getY() + spriteRight.getHeight()/2)/PIXELS_TO_METERS);
        //Create a Fixture
        FixtureDef rightPlatformF = new FixtureDef();
        rightPlatformF.density =1;
        rightPlatformF.restitution = 0f;
        //Shape
        PolygonShape rightPlatformR = new PolygonShape();
        rightPlatformR.setAsBox(spriteRight.getWidth()/2/PIXELS_TO_METERS,spriteRight.getHeight()/2/PIXELS_TO_METERS);
        rightPlatformF.shape = rightPlatformR;
        rightPlatformF.filter.categoryBits = WORLD_ENTITY;
        rightPlatformF.filter.maskBits = PHYSICS_ENTITY; // allow collision with boxes
        //Create a Body
        bodyRightPlatform = world.createBody(rightPlatformB);
        bodyRightPlatform.createFixture(rightPlatformF);
        rightPlatformR.dispose();

        //UPPER RIGHT FLOATING PLATFORM
        //Create a BodyDef
        BodyDef rightUpperPlatformB = new BodyDef();
        rightUpperPlatformB.type = BodyDef.BodyType.StaticBody;
        rightUpperPlatformB.position.set((spriteUpperRight.getX()+spriteUpperRight.getWidth()/2)/PIXELS_TO_METERS, (spriteUpperRight.getY() + spriteUpperRight.getHeight()/2)/PIXELS_TO_METERS);
        //Create a Fixture
        FixtureDef rightUpperPlatformF = new FixtureDef();
        rightUpperPlatformF.density =1;
        rightUpperPlatformF.restitution = 0f;
        //Shape
        PolygonShape rightUpperPlatformR = new PolygonShape();
        rightUpperPlatformR.setAsBox(spriteUpperRight.getWidth()/2/PIXELS_TO_METERS,spriteUpperRight.getHeight()/2/PIXELS_TO_METERS);
        rightUpperPlatformF.shape = rightUpperPlatformR;
        rightUpperPlatformF.filter.categoryBits = WORLD_ENTITY;
        rightUpperPlatformF.filter.maskBits = PHYSICS_ENTITY; // allow collision with boxes
        //Create a Body
        bodyUpperRightPlatform = world.createBody(rightUpperPlatformB);
        bodyUpperRightPlatform.createFixture(rightUpperPlatformF);
        rightUpperPlatformR.dispose();

        //PLAYER
        archer1 = new ArcherSprite1();
        archer1.setPosition(-400, -archer1.getHeight()/2);
        archer2 = new ArcherSprite2();
        archer2.setPosition(360, -archer2.getHeight()/2);

        // Creates body definition of the archers
        BodyDef bodyDefArcher1 = new BodyDef();
        bodyDefArcher1.type = BodyDef.BodyType.DynamicBody;
        bodyDefArcher1.fixedRotation = true;
        bodyDefArcher1.position.set((archer1.getX() + archer1.getWidth()/2) / PIXELS_TO_METERS,
                (archer1.getY() + archer1.getHeight()/2) / PIXELS_TO_METERS);
        body1 = world.createBody(bodyDefArcher1);

        BodyDef bodyDefArcher2 = new BodyDef();
        bodyDefArcher2.type = BodyDef.BodyType.DynamicBody;
        bodyDefArcher2.fixedRotation = true;
        bodyDefArcher2.position.set((archer2.getX() + archer2.getWidth()/2) / PIXELS_TO_METERS,
                (archer2.getY() + archer2.getHeight()/2) / PIXELS_TO_METERS);
        body2 = world.createBody(bodyDefArcher2);

        // creates the shapes that the physics bodies will have
        PolygonShape shape = new PolygonShape();
        PolygonShape shape2 = new PolygonShape();
        shape.setAsBox(archer1.getWidth()/2 / PIXELS_TO_METERS, archer1.getHeight()/2 / PIXELS_TO_METERS);
        shape2.setAsBox(archer2.getWidth()/2 / PIXELS_TO_METERS, archer2.getHeight()/2 / PIXELS_TO_METERS);

        // Apply Attributes to each physics body
        FixtureDef fixtureDefArcher1 = new FixtureDef();
        fixtureDefArcher1.shape = shape;
        fixtureDefArcher1.density = 15f;
        fixtureDefArcher1.restitution = 0f;
        fixtureDefArcher1.friction = 1f;
        fixtureDefArcher1.filter.categoryBits = PHYSICS_ENTITY;
        fixtureDefArcher1.filter.maskBits = WORLD_ENTITY;
        body1.createFixture(fixtureDefArcher1);

        FixtureDef fixtureDefArcher2 = new FixtureDef();
        fixtureDefArcher2.shape = shape;
        fixtureDefArcher2.density = 15f;
        fixtureDefArcher2.restitution = 0f;
        fixtureDefArcher2.friction = 1f;
        fixtureDefArcher2.filter.categoryBits = PHYSICS_ENTITY;
        fixtureDefArcher2.filter.maskBits = WORLD_ENTITY;
        body2.createFixture(fixtureDefArcher2);

        shape.dispose();
        shape2.dispose();

        Gdx.input.setInputProcessor(this);
        //debugRenderer = new Box2DDebugRenderer();
        camera = new OrthographicCamera(Gdx.graphics.getWidth(),Gdx.graphics.getHeight());
        archer1.setAlive();
        archer2.setAlive();

    }

    private void renderBackground() {
        backgroundSprite.draw(batch);
    }

    private void shootArrow1() {
        //INITIATE SHOT SOUND
        shotSound.play();

        //DECIDE SHOT DIRECTION
        if(body1.getPosition().x > body2.getPosition().x)
            shootRight1 = false;
        else
            shootRight1 = true;

        if(!alreadyShot1) {
            //Arrow1 Sprite Creation
            arrow1Sprite = new Sprite(arrow1);

            if(shootRight1) {
                if (!arrow1Direction) {
                    arrow1Sprite.flip(true,false);
                    arrow1Direction = true;
                    if(!isRight1)
                    {
                        archer1.turnAroundLeft();
                    }
                }
                arrow1Sprite.setPosition(archer1.getX() + archer1.getWidth() + 10, archer1.getY() + archer1.getHeight() / 2);
            }
            else {
                if(arrow1Direction) {
                    arrow1Sprite.flip(true, false);
                    arrow1Direction = false;
                }
                arrow1Sprite.setPosition(archer1.getX() - archer1.getWidth() - 10, archer1.getY() + archer1.getHeight() / 2);
            }

            // Arrow Shape Declaration
            PolygonShape arrow1Shape = new PolygonShape();
            arrow1Shape.setAsBox(arrow1Sprite.getWidth() / 2 / PIXELS_TO_METERS, arrow1Sprite.getHeight() / 2 / PIXELS_TO_METERS);

            //Arrow Body Def
            BodyDef arrow1BodyDef = new BodyDef();
            arrow1BodyDef.position.set(1,1);
            arrow1BodyDef.type = BodyDef.BodyType.DynamicBody;
            arrow1BodyDef.position.set((arrow1Sprite.getX() + arrow1Sprite.getWidth() / 2) / PIXELS_TO_METERS,
                    (arrow1Sprite.getY() + arrow1Sprite.getHeight() / 2) / PIXELS_TO_METERS);
            arrow1BodyDef.fixedRotation = true;
            arrow1Body = world.createBody(arrow1BodyDef);

            //Arrow1 Fixture Def
            FixtureDef arrow1FixtureDef = new FixtureDef();
            arrow1FixtureDef.shape = arrow1Shape;
            arrow1FixtureDef.density = 0.1f;
            arrow1FixtureDef.restitution = 1.0f;
            arrow1FixtureDef.filter.categoryBits = WORLD_ENTITY;
            arrow1FixtureDef.filter.maskBits = PHYSICS_ENTITY;

            arrow1Body.createFixture(arrow1FixtureDef);
            arrow1Shape.dispose();
            alreadyShot1 = true;
        }
        else{
            if(shootRight1)
            {
                if (!arrow1Direction) {
                    arrow1Sprite.flip(true,false);
                    arrow1Direction = true;
                }
                arrow1Sprite.setPosition(archer1.getX() + archer1.getWidth() + 10, archer1.getY() + archer1.getHeight() / 2);
            }
            else {
                if(arrow1Direction) {
                    arrow1Sprite.flip(true, false);
                    arrow1Direction = false;
                }
                arrow1Sprite.setPosition(archer1.getX() - archer1.getWidth() - 10, archer1.getY() + archer1.getHeight() / 2);
            }

            arrow1Body.setTransform((arrow1Sprite.getX() + arrow1Sprite.getWidth() / 2) / PIXELS_TO_METERS,
                    (arrow1Sprite.getY() + arrow1Sprite.getHeight() / 2) / PIXELS_TO_METERS,0);
        }

        canShoot1 = false;
        if(shootRight1)
            arrow1Body.setLinearVelocity(arrowVelocity, 0f);
        else
            arrow1Body.setLinearVelocity(-arrowVelocity, 0f);
    }

    public void shootArrow2() {
        //INITIATE SHOT SOUND
        shotSound.play();

        //DECIDE SHOT DIRECTION
        if(body2.getPosition().x > body1.getPosition().x)
            shootRight2 = false;
        else
            shootRight2 = true;

        if(!alreadyShot2) {
            //Arrow1 Sprite Creation
            arrow2Sprite = new Sprite(arrow2);


            if(shootRight2) {
                if (!arrow2Direction) {
                    arrow2Sprite.flip(true,false);
                    arrow2Direction = true;
                }
                arrow2Sprite.setPosition(archer2.getX() + archer2.getWidth() + 10, archer2.getY() + archer2.getHeight() / 2);
            }
            else {
                if (arrow2Direction) {
                    arrow2Sprite.flip(true,false);
                    arrow2Direction = false;
                }
                arrow2Sprite.setPosition(archer2.getX() - archer2.getWidth() - 10, archer2.getY() + archer2.getHeight() / 2);
            }
            // Arrow Shape Declaration
            PolygonShape arrow2Shape = new PolygonShape();
            arrow2Shape.setAsBox(arrow2Sprite.getWidth() / 2 / PIXELS_TO_METERS, arrow2Sprite.getHeight() / 2 / PIXELS_TO_METERS);

            //Arrow Body Def
            BodyDef arrow2BodyDef = new BodyDef();
            arrow2BodyDef.position.set(1,1);
            arrow2BodyDef.type = BodyDef.BodyType.DynamicBody;
            arrow2BodyDef.position.set((arrow2Sprite.getX() + arrow2Sprite.getWidth() / 2) / PIXELS_TO_METERS,
                    (arrow2Sprite.getY() + arrow2Sprite.getHeight() / 2) / PIXELS_TO_METERS);
            arrow2BodyDef.fixedRotation = true;
            arrow2Body = world.createBody(arrow2BodyDef);

            //Arrow1 Fixture Def
            FixtureDef arrow2FixtureDef = new FixtureDef();
            arrow2FixtureDef.shape = arrow2Shape;
            arrow2FixtureDef.density = 0.1f;
            arrow2FixtureDef.restitution = 1.0f;
            arrow2FixtureDef.filter.categoryBits = WORLD_ENTITY;
            arrow2FixtureDef.filter.maskBits = PHYSICS_ENTITY;

            arrow2Body.createFixture(arrow2FixtureDef);
            arrow2Shape.dispose();
            alreadyShot2 = true;
        }
        else{
            if(shootRight2) {
                if (!arrow2Direction) {
                    arrow2Sprite.flip(true,false);
                    arrow2Direction = true;
                }
                arrow2Sprite.setPosition(archer2.getX() + archer2.getWidth() + 10, archer2.getY() + archer2.getHeight() / 2);
            }
            else {
                if(arrow2Direction) {
                    arrow2Sprite.flip(true, false);
                    arrow2Direction = false;
                }
                arrow2Sprite.setPosition(archer2.getX() - archer2.getWidth() - 10, archer2.getY() + archer2.getHeight() / 2);
            }

            arrow2Body.setTransform((arrow2Sprite.getX() + arrow2Sprite.getWidth() / 2) / PIXELS_TO_METERS,
                    (arrow2Sprite.getY() + arrow2Sprite.getHeight() / 2) / PIXELS_TO_METERS,0);

        }

        canShoot2 = false;
        if(shootRight2)
            arrow2Body.setLinearVelocity(arrowVelocity, 0f);
        else
            arrow2Body.setLinearVelocity(-arrowVelocity, 0f);
    }
    @Override
    public void render(float delta) {

        archer1.update(elapsedTime);
        archer2.update(elapsedTime2);
        camera.update();
        switch (status) {
            case RUN:
                // Step the physics simulation forward at a rate of 60hz
                world.step(1f/60f, 6, 2);
                if(isLeft1 && body1.getLinearVelocity().x >= -MAX_HORIZONTAL_VELOCITY)
                {
                    body1.applyForceToCenter(-HORIZONTAL_VELOCITY, 0f, true);
                }
                if(isRight1 && body1.getLinearVelocity().x <= MAX_HORIZONTAL_VELOCITY)
                {
                    body1.applyForceToCenter(HORIZONTAL_VELOCITY, 0f, true);
                }
                if(isLeft2 && body2.getLinearVelocity().x >= -MAX_HORIZONTAL_VELOCITY)
                {
                    body2.applyForceToCenter(-HORIZONTAL_VELOCITY, 0f, true);
                }
                if(isRight2 && body2.getLinearVelocity().x <= MAX_HORIZONTAL_VELOCITY)
                {
                    body2.applyForceToCenter(HORIZONTAL_VELOCITY, 0f, true);
                }
                break;

            case PAUSE: //Pause state occur between rounds, and when game is paused by clicking ESC button
                isHit = false;
                if(hit)
                {
                    Timer.schedule(new Timer.Task(){
                        public void run() {
                            fontX2 = 10000;
                            fontY2 = 10000;
                            archer1.setAlive();
                            archer2.setAlive();
                            resume();
                        }
                    }, 5);
                }
                else
                {
                    Timer.schedule(new Timer.Task(){
                        public void run() {
                            fontX1 = 10000;
                            fontY1 = 10000;
                            archer1.setAlive();
                            archer2.setAlive();
                            resume();
                        }
                    }, 5);
                }
                break;
            case END:
                if(lose1)
                {
                    Timer.schedule(new Timer.Task(){
                        public void run() {
                            System.exit(1);
                        }
                    }, 5);
                    endfontX1 =-165;
                    endfontY1 = 200;
                }
                if(lose2)
                {
                    Timer.schedule(new Timer.Task(){
                        public void run() {
                            System.exit(1);
                        }
                    }, 5);
                    endfontX2 =-165;
                    endfontY2 = 200;
                }
                break;
        }// end switch

        //The Color of the World
        Gdx.gl.glClearColor(1, 1, 1, 1);
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);

        batch.setProjectionMatrix(camera.combined);
        //debugMatrix = batch.getProjectionMatrix().cpy().scale(PIXELS_TO_METERS, PIXELS_TO_METERS, 0);

        // Initialize the positions of the sprites
        archer1.setPosition((body1.getPosition().x * PIXELS_TO_METERS) - archer1.getWidth()/2,
                (body1.getPosition().y * PIXELS_TO_METERS) -archer1.getHeight()/2 );

        archer2.setPosition((body2.getPosition().x * PIXELS_TO_METERS) - archer2.getWidth()/2,
                (body2.getPosition().y * PIXELS_TO_METERS) - archer2.getHeight()/2);
        archer2.setColor(1,.8f,.8f,1);

        batch.begin();
        //Draw background
        renderBackground();

        //Draw Platforms
        spriteMid.draw(batch);
        spriteLeft.draw(batch);
        spriteUpperLeft.draw(batch);
        spriteRight.draw(batch);
        spriteUpperRight.draw(batch);
        font.draw(batch, "Archer1 HP: "+ archer1HP,-475,215);
        font.draw(batch, "Archer2 HP: "+ archer2HP,300,215);
        font.getData().setScale(2);
        font.draw(batch, "Archer1 hit Archer2! \nArcher2 loses 1 HP", fontX1, fontY1);
        font.draw(batch, "Archer2 hit Archer1! \nArcher1 loses 1 HP", fontX2, fontY2);
        font.draw(batch, "Archer1 has defeated Archer2", endfontX1, endfontY1);
        font.draw(batch, "Archer2 has defeated Archer1", endfontX2, endfontY2);

        //Arrows are in bounds
        if(!canShoot1) {
            //Arrow Draw
            //Arrow goes off screen
            if(arrow1Body.getPosition().x < -5 || arrow1Body.getPosition().x > 5 || arrow1Body.getPosition().y < -2.22)
                canShoot1 = true;

            else {
                arrow1Sprite.setPosition((arrow1Body.getPosition().x * PIXELS_TO_METERS) - arrow1Sprite.getWidth() / 2,
                        (arrow1Body.getPosition().y * PIXELS_TO_METERS) - arrow1Sprite.getHeight() / 2);
                //arrow1Sprite.setTexture(arrow1);
                arrow1Sprite.draw(batch);
            }
        }
        if(!canShoot2) {
            //Arrow Draw
            //Arrow goes off screen
            if(arrow2Body.getPosition().x < -5 || arrow2Body.getPosition().x > 5 || arrow2Body.getPosition().y < -2.22)
                canShoot2 = true;

            else {
                arrow2Sprite.setPosition((arrow2Body.getPosition().x * PIXELS_TO_METERS) - arrow2Sprite.getWidth() / 2,
                        (arrow2Body.getPosition().y * PIXELS_TO_METERS) - arrow2Sprite.getHeight() / 2);
                //arrow1Sprite.setTexture(arrow1);
                arrow2Sprite.draw(batch);
            }
        }

        if(!canInput1){
            canInput1 = true;
                Timer.schedule(new Timer.Task() {
                    public void run() {
                        System.out.print("NFELDS N");
                        canInput2 = true;

                    }
                }, 12);
        }

        //Draw Players
        archer1.draw(batch);
        archer2.draw(batch);

        world.setContactListener(new ContactListener() {

            @Override
            public void beginContact(Contact contact) {
                // Checks to see if Archer1 has contact with a floor
                if ((contact.getFixtureA().getBody() == bodyEdgeScreen && contact.getFixtureB().getBody() == body1) ||
                        (contact.getFixtureA().getBody() == bodyLeftPlatform && contact.getFixtureB().getBody() == body1) ||
                        (contact.getFixtureA().getBody() == bodyMidPlatform && contact.getFixtureB().getBody() == body1) ||
                        (contact.getFixtureA().getBody() == bodyRightPlatform && contact.getFixtureB().getBody() == body1) ||
                        (contact.getFixtureA().getBody() == bodyUpperLeftPlatform && contact.getFixtureB().getBody() == body1) ||
                        (contact.getFixtureA().getBody() == bodyUpperRightPlatform && contact.getFixtureB().getBody() == body1 ||
                                (contact.getFixtureA().getBody() == bodyEdgeScreen && contact.getFixtureB().getBody() == body1) )
                ){
                    isWKeyPressed = 0;
                    isAir1 = false;


                }
                // Checks to see if Archer2 has contact with a floor
                if( (contact.getFixtureA().getBody()== bodyEdgeScreen && contact.getFixtureB().getBody() == body2) ||
                        (contact.getFixtureA().getBody() == bodyLeftPlatform && contact.getFixtureB().getBody() == body2) ||
                        (contact.getFixtureA().getBody() == bodyMidPlatform && contact.getFixtureB().getBody() == body2) ||
                        (contact.getFixtureA().getBody() == bodyRightPlatform && contact.getFixtureB().getBody() == body2) ||
                        (contact.getFixtureA().getBody() == bodyUpperLeftPlatform && contact.getFixtureB().getBody() == body2) ||
                        (contact.getFixtureA().getBody() == bodyUpperRightPlatform && contact.getFixtureB().getBody() == body2) ||
                        (contact.getFixtureA().getBody() == bodyEdgeScreen && contact.getFixtureB().getBody() == body2) ){
                    isUpKeyPressed = 0;
                    isAir2 = false;
                }

                // Archer1 arrow MISS detection
                if ( (contact.getFixtureA().getBody() == bodyEdgeScreen && contact.getFixtureB().getBody() == arrow1Body) ||
                        (contact.getFixtureA().getBody() == bodyEdgeRight && contact.getFixtureB().getBody() == arrow1Body) ||
                        (contact.getFixtureA().getBody() == bodyEdgeLeft && contact.getFixtureB().getBody() == arrow1Body) ||
                        (contact.getFixtureA().getBody()== bodyEdgeScreen && contact.getFixtureB().getBody() == arrow1Body) ||
                        (contact.getFixtureA().getBody() == bodyLeftPlatform && contact.getFixtureB().getBody() == arrow1Body) ||
                        (contact.getFixtureA().getBody() == bodyMidPlatform && contact.getFixtureB().getBody() == arrow1Body) ||
                        (contact.getFixtureA().getBody() == bodyRightPlatform && contact.getFixtureB().getBody() == arrow1Body) ||
                        (contact.getFixtureA().getBody() == bodyUpperLeftPlatform && contact.getFixtureB().getBody() == arrow1Body) ||
                        (contact.getFixtureA().getBody() == bodyUpperRightPlatform && contact.getFixtureB().getBody() == arrow1Body) ){

                    canShoot1 = true;
                    arrow1Body.setLinearVelocity(0f,0f);

                }
                // Archer2 arrow MISS detection
                if ( (contact.getFixtureA().getBody() == bodyEdgeScreen && contact.getFixtureB().getBody() == arrow2Body) ||
                        (contact.getFixtureA().getBody() == bodyEdgeRight && contact.getFixtureB().getBody() == arrow2Body) ||
                        (contact.getFixtureA().getBody() == bodyEdgeLeft && contact.getFixtureB().getBody() == arrow2Body) ||
                        (contact.getFixtureA().getBody()== bodyEdgeScreen && contact.getFixtureB().getBody() == arrow2Body) ||
                        (contact.getFixtureA().getBody() == bodyLeftPlatform && contact.getFixtureB().getBody() == arrow2Body) ||
                        (contact.getFixtureA().getBody() == bodyMidPlatform && contact.getFixtureB().getBody() == arrow2Body) ||
                        (contact.getFixtureA().getBody() == bodyRightPlatform && contact.getFixtureB().getBody() == arrow2Body) ||
                        (contact.getFixtureA().getBody() == bodyUpperLeftPlatform && contact.getFixtureB().getBody() == arrow2Body) ||
                        (contact.getFixtureA().getBody() == bodyUpperRightPlatform && contact.getFixtureB().getBody() == arrow2Body) ){

                    canShoot2 = true;
                    arrow2Body.setLinearVelocity(0f,0f);

                }

                //Arrow1 contacts Archer2
                if(contact.getFixtureA().getBody() == body2 && contact.getFixtureB().getBody() == arrow1Body) {
                    if (archer2HP == 1)
                    {
                        archer2HP --;
                        lose2 = true;
                        archer2.kill();
                        end();
                    }
                    else {
                        archer2HP--;
                        hit = false;
                        isHit = true;
                        canInput1 = false;
                        canInput2 = false;
                        fontX1 = -125;
                        fontY1 = 200;
                        archer2.kill();
                        arrow1Body.setLinearVelocity(0,0);
                    }
                }
                //Arrow2 contacts Archer1
                if(contact.getFixtureA().getBody() == body1 && contact.getFixtureB().getBody() == arrow2Body)
                {
                    if(archer1HP == 1) {
                        archer1HP--;
                        lose1 = true;
                        archer1.kill();
                        end();
                    }
                    else {
                        archer1HP--;
                        hit = true;
                        isHit = true;
                        canInput1 = false;
                        canInput2 = false;
                        fontX2 = -125;
                        fontY2 = 200;
                        archer1.kill();
                        arrow2Body.setLinearVelocity(0,0);
                    }
                }

            }

            @Override
            public void endContact(Contact contact) {
            }

            @Override
            public void preSolve(Contact contact, Manifold oldManifold) {
            }

            @Override
            public void postSolve(Contact contact, ContactImpulse impulse) {
            }
        });

        if (isHit) {
            if(alreadyShot1){
                arrow1Body.setLinearVelocity(0,0);
                arrow1Sprite.setPosition(1000,-1000);
                arrow1Body.setTransform((arrow1Sprite.getX() + arrow1Sprite.getWidth() / 2) / PIXELS_TO_METERS,
                        (arrow1Sprite.getY() + arrow1Sprite.getHeight() / 2) / PIXELS_TO_METERS,0);
            }
            if(alreadyShot2) {
                arrow2Body.setLinearVelocity(0,0);
                arrow2Sprite.setPosition(1000, -1000);
                arrow2Body.setTransform((arrow2Sprite.getX() + arrow2Sprite.getWidth() / 2) / PIXELS_TO_METERS,
                        (arrow2Sprite.getY() + arrow2Sprite.getHeight() / 2) / PIXELS_TO_METERS, 0);
            }
            if (hit) {
                System.out.print("Archer2 loses HP");
                pause();
            } else {
                System.out.print("Archer1 loses HP");
                pause();
            }
        }

        batch.end();
        //debugRenderer.render(world, debugMatrix);

        if (Gdx.input.isKeyJustPressed(Keys.ESCAPE)) {
            if (status == GameStatus.RUN) {
                setGameState(status = GameStatus.PAUSE); // This will stop everything except background music
                game.setScreen(mainmenu);
            }
        }


    }

    @Override
    public void resize(int width, int height) {
    }

    @Override
    public void show() {
        Gdx.input.setInputProcessor(this);
    }

    @Override
    public void hide() {
    }

    @Override
    public void pause() {
        this.status = GameStatus.PAUSE;
    }

    private void end(){this.status = GameStatus.END; }

    @Override
    public void resume() {
        body1.setTransform(-3, 0,0);
        body2.setTransform(3,0,0);
        body1.setLinearVelocity(0,100);
        body2.setLinearVelocity(0,100);
        isAir1 = false;
        isAir2 = false;
        this.status = GameStatus.RUN;
    }

    @Override
    public void dispose() {
        shotSound.dispose();
        gameMusic.dispose();
    }


    public void setGameState(GameStatus s) {
        this.status = s;
    }

    @Override
    public boolean keyDown(int keycode) {

            //__________________PLAYER 1 MOVEMENT______________________________________________
            //Shoot
            if (keycode == Input.Keys.SPACE && canInput2 && canShoot1)
                shootArrow1();

            if (keycode == Input.Keys.D) {
                    body1.setLinearVelocity(0,body1.getLinearVelocity().y);
                isRight1 = true;
            }

            // Checks for movement to the left
            else if (keycode == Input.Keys.A) {
                    body1.setLinearVelocity(0,body1.getLinearVelocity().y);
                isLeft1 = true;

            }

            if (keycode == Input.Keys.W) {
                isAir1 = true;
                if (isWKeyPressed < 2) {
                    body1.applyForceToCenter(0f, 500f, true);
                    isWKeyPressed++;
                } else if (isWKeyPressed >= 2) {
                    // Locks movement to the right and resets counter
                    body1.applyForceToCenter(0, 0, true);

                }
            }
            //__________________PLAYER 2 MOVEMENT______________________________________________
            //Shoot
            if (keycode == Keys.ENTER && canShoot2 && canInput2)
                shootArrow2();

            if (keycode == Input.Keys.RIGHT) {
                    body2.setLinearVelocity(0, body2.getLinearVelocity().y);
                isRight2 = true;
            }
            // Checks for movement to the left
            else if (keycode == Input.Keys.LEFT) {
                    body2.setLinearVelocity(0, body2.getLinearVelocity().y);
                isLeft2 = true;
            }

            if (keycode == Input.Keys.UP) {
                isAir2 = true;
                if (isUpKeyPressed < 2) {
                    body2.applyForceToCenter(0f, 500f, true);
                    isUpKeyPressed++;
                } else if (isUpKeyPressed >= 2) {
                    // Locks movement to the right and resets counter
                    body2.applyForceToCenter(0, 0, true);

                }
            }

        return false;
    }


    @Override
    public boolean keyUp(int keycode) {

        //__________________PLAYER 1 MOVEMENT______________________________________________

        // Checks for movement to the right

        if(keycode == Input.Keys.D) {
            isRight1 = false;
        }

        // Checks for movement to the left
        if (keycode == Input.Keys.A) {
            isLeft1 = false;
        }


        //__________________PLAYER 2 MOVEMENT______________________________________________

        // Checks for movement to the right
        if( keycode == Input.Keys.RIGHT) {
            isRight2 = false;
        }

        // Checks for movement to the left
        if (keycode == Input.Keys.LEFT) {
            isLeft2 = false;
        }


        return false;
    }

    @Override
    public boolean keyTyped(char character) {
        return false;
    }

    @Override
    public boolean touchDown(int screenX, int screenY, int pointer, int button) {
        return false;
    }

    @Override
    public boolean touchUp(int screenX, int screenY, int pointer, int button) {
        return false;
    }

    @Override
    public boolean touchDragged(int screenX, int screenY, int pointer) {
        return false;
    }

    @Override
    public boolean mouseMoved(int screenX, int screenY) {
        return false;
    }

    @Override
    public boolean scrolled(int amount) {
        return false;
    }
}