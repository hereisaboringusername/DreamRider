package com.mygdx.game;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.utils.Align;

public class InstructionScreen implements Screen {

    final MyGdxGame game;
    Texture background;
    Sprite backgroundSprite;
    CharSequence helpMessage;

    public InstructionScreen(final MyGdxGame game) {
        create();
        this.game = game;
    }

    public void create() {
        background = new Texture("splash.png");
        backgroundSprite = new Sprite(background);
        backgroundSprite.setBounds(0f, 0f, 1200f, 900f);
        helpMessage = "Welcome to ARCHERY TO DEATH!! \n" +
                "+++++++ \n\n\n\n" +
                "This game is designed to be played by two players only. \n\n" +
                "The 1st Player starts on the left side of the screen and is controlled with the WASD keys and Space to shoot. \n" +
                "The 2ns Player starts on the right side of the screen and is controlled with the arrow keys and ENTER to shoot. \n" +
                "This is the battlefield between two rival archers \n" +
                "Whoever kill the other one three times wins the match \n" +
                "The positions of the players will reset after each kill. \n\n" +
                "Click anywhere to return to main menu.";
    }

    @Override
    public void render(float delta) {
        Gdx.gl.glClearColor(0, 0, 0.2f, 1);
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);

        game.batch.begin();
        backgroundSprite.draw(game.batch);
        game.font.setColor(0f, 100f, 0f, 255f);
        game.font.draw(game.batch, helpMessage, 180, 400, 400, Align.center, false);
        game.batch.end();

        if (Gdx.input.isTouched()) {
            game.setScreen(new MainMenuScreen(game));
            dispose();
        }
    }

    @Override
    public void resize(int width, int height) {}
    @Override
    public void show() {}
    @Override
    public void hide() {}
    @Override
    public void pause() {}
    @Override
    public void resume() {}
    @Override
    public void dispose() {}
}