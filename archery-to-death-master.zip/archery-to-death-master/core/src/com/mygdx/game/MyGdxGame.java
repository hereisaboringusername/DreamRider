package com.mygdx.game;

import com.badlogic.gdx.Game;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.audio.Music;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;

public class MyGdxGame extends Game {
	SpriteBatch batch;
	OrthographicCamera camera;
	public BitmapFont font;
	Music gameMusic;


	@Override
	public void create () {
		batch = new SpriteBatch();
		font = new BitmapFont();

		//SET CURRENT SCREEN TO MAIN MENU SCREEN
		this.setScreen(new MainMenuScreen(this));

		//Initiate Background Music
		gameMusic =  Gdx.audio.newMusic(Gdx.files.internal("Common Fight.ogg"));
		gameMusic.setLooping(true);
		gameMusic.play();

	}


	@Override
	public void render () {super.render();
	}

	@Override
	public void dispose () {
		batch.dispose();
	}


}
